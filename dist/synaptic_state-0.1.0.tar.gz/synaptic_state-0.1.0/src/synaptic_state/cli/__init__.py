"""CLI for SynapticAI."""
